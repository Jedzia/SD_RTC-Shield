
#include "api.h"

int my_func(int a)
{
	return a * 3;
}
