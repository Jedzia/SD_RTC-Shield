int my_func(int a);
